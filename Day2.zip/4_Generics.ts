// Generics allows you to create a component that can work over a variety of types 
// rather than a single one, without loosing type safety and intellisense

// class Queue {
//     private _data: number[] = [];

//     push(d: number) {
//         this._data.push(d);
//     }

//     pop(): number {
//         return this._data.shift();
//     }
// }

// var numberQ = new Queue();

// numberQ.push(10);
// numberQ.push(20);
// numberQ.push(30);

// console.log(numberQ.pop());
// console.log(numberQ.pop());
// console.log(numberQ.pop());

// ----------------------------------------------------- Flexibility, we can use 'any' as a type

// class Queue {
//     private _data: any[] = [];

//     push(d: any) {
//         this._data.push(d);
//     }

//     pop(): any {
//         return this._data.shift();
//     }
// }

// var numberQ = new Queue();

// numberQ.push(10);
// numberQ.push(20);
// numberQ.push(30);

// console.log(numberQ.pop());
// console.log(numberQ.pop());
// console.log(numberQ.pop());

// var namesQ = new Queue();

// namesQ.push("abc");
// namesQ.push("xyz");
// namesQ.push(30);

// console.log(namesQ.pop());
// console.log(namesQ.pop());
// console.log(namesQ.pop());

// ----------------------------------------------------------------------------- Generics
// class Queue<T> {
//     private _data: T[] = [];

//     push(d: T) {
//         this._data.push(d);
//     }

//     pop(): T {
//         return this._data.shift();
//     }
// }

// var numberQ = new Queue<number>();
// numberQ.push(10);
// numberQ.push(20);
// numberQ.push(30);
// console.log(numberQ.pop());
// console.log(numberQ.pop());
// console.log(numberQ.pop());

// var namesQ = new Queue<string>();
// namesQ.push("abc");
// namesQ.push("xyz");
// namesQ.push("manish");
// console.log(namesQ.pop().toUpperCase());
// console.log(namesQ.pop().toUpperCase());
// console.log(namesQ.pop().toUpperCase());

// ----------------------------------------------------------------------------- Constraints
interface ILength {
    length: number;
}

function getLength<T extends ILength>(arg: T) {
    return arg.length;
}

console.log(getLength<string>("Manish"));
console.log(getLength<string[]>(["Manish", "Abhijeet"]));
console.log(getLength<number[]>([10, 20, 30, 40, 50]));

// console.log(getLength<number>(10));